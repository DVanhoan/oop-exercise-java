public class Main {
    public static void main(String[] args) {
        Circle c1 = new Circle();

        System.out.println(c1.Circle(9));

    }
}