public class MyRectangle {

    private int id;
    private String name;

    


}
