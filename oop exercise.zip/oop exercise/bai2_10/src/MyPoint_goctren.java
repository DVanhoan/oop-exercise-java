public class MyPoint_goctren {
}
