public class MyPoint_gocduoi {
}
