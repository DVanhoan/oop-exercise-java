public class Main {
    public static void main(String[] args) {
        Rectangle c = new Rectangle(1.0f,1.0f);
        System.out.println(c.toString());
        System.out.println("Area is: "+c.getArea()+"\nperimeter is: "+c.getPerimeter());

    }
}