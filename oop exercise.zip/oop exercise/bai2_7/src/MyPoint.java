import java.util.ArrayList;
import java.util.List;

public class MyPoint {
    private List<MyLine> myLines;

    private int x;
    private int y;
    public MyPoint() {
        myLines = new ArrayList<>();
    }

    public void addMyLine(MyLine myLine) {
        myLine.add(myLine);
    }

    public List<MyLine> getMyLine() {
        return getMyLine();
    }

    public MyPoint(List<MyLine> myLines, int x, int y) {
        this. = accounts;
        this.id = id;
        this.name = name;
        this.discount = discount;

}
