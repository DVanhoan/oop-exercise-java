public class Main {
    public static void main(String[] args) {

        Player p = new Player(10, 3,4);
        Ball b = new Ball(2,5,7);

        System.out.println(b.toString());
        System.out.println(p.kick());

    }
}