public class Main {
    public static void main(String[] args) {
        MyPolynomial p1 = new MyPolynomial(1, 2, 3, 4, 5);
        MyPolynomial p2 = new MyPolynomial(4,5,6,7);


        System.out.println("ket qua cua day so la: "+p2.add(p1));



    }
}